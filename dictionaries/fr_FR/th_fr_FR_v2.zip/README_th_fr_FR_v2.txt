
Dictionnaire des synonymes myThes pour OpenOffice.org 2.1
________________________________________________________________________________

Ce dictionnaire des synonymes est en cours de conception.
Les resultats qu'il fournit doivent �tre donc consid�r�s comme potentiellement erron�s.

myThes est le format de thesaurus de OOo � partir de la version 2.0 developp� par Kevin Hendricks sur la base des travaux de l'universit� de Priceton
http://lingucomponent.openoffice.org/thesaurus.html

Cette version est incompatible avec le format binaire utilis� pour les versions 1.x d'OpenOffice.org

Sa r�alisation dans le format 1.0 a �t� initi�e par Frederic Labb�. Nous lui rendons ici hommage.

La version 2 a �t� transform�e par la soci�t� Indesko - Laurent Godard (lgodard@indesko.com)
Les cat�gories grammaticales des mots ont �t� compl�t�es sur la base de InDico, dictionnaire taggu� developp� par InDesko et issu de la transformation des listes de l'abu (http://abu.cnam.fr/)

Les seuls changements de la version 2.1 par rapport � la version 2.0 sont la
modification des mots avec ligatures (non-reconnus auparavant).
Ce thesaurus a �t� d�couvert ici:
http://user.services.openoffice.org/fr/forum/viewtopic.php?p=15783#15783

________________________________________________________________________________

INSTALLATION
________________________________________________________________________________

- Fermer OpenOffice.org
- copier les fichiers .dat et .idx ans le repertoire
<ooo>/share/dict/ooo o� <ooo> traduit le repertoire d'installation d'OpenOffice.org 
- �diter le fichier dictionary.lst
- ajouter la ligne THES fr FR th_fr_FR_v2

________________________________________________________________________________

LICENCE
________________________________________________________________________________

ce dictionnaire est sous licence LGPL
http://www.gnu.org/copyleft/lesser.html